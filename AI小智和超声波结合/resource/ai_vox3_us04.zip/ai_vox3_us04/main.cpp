#include <Arduino.h>
#include <ArduinoJson.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

constexpr gpio_num_t kUs04PinTrig = GPIO_NUM_2;
constexpr gpio_num_t kUs04PinEcho = GPIO_NUM_1;
constexpr uint16_t kUs04Timeout = 30000;

/**
 * @brief 测量US04超声波传感器的距离
 *
 * 该函数通过控制US04超声波传感器发送触发信号并接收回波信号，
 * 计算出物体与传感器之间的距离。
 *
 * 工作原理：发送10微秒的高电平触发信号，传感器发出超声波脉冲，
 * 当接收到反射回来的超声波时，回波引脚会输出高电平信号，
 * 通过测量高电平持续时间来计算距离。
 *
 * @return float 返回测量到的距离值（单位：厘米）
 *               如果测量超时则返回-1
 */
float MeasureUs04UltrasonicDistance() {
  digitalWrite(kUs04PinTrig, LOW);
  delayMicroseconds(2);
  digitalWrite(kUs04PinTrig, HIGH);
  delayMicroseconds(10);
  digitalWrite(kUs04PinTrig, LOW);

  const auto duration = pulseIn(kUs04PinEcho, HIGH, kUs04Timeout);

  if (duration <= 0) {
    printf("Error: US04 sensor measure timeout.\n");
    return -1.0f;
  }
  return static_cast<float>(duration * 0.034 / 2);
}

/**
 * @brief MCP工具 - US04超声波传感器测距功能
 *
 * 该函数注册一个名为 "user.ultrasonic_sensor.get_distance" 的MCP工具，
 * 用于获取US04超声波传感器测量的距离数据。
 *
 * 工具名称: user.ultrasonic_sensor.get_distance
 * 工具描述: Get distance from US04 ultrasonic sensor
 *
 * 参数: 无
 *
 * 返回值:
 *   - 成功时返回距离值（厘米），作为字符串形式返回
 *   - 失败时返回错误信息
 */
void McpToolUs04UltrasonicSensor() {
  RegisterUserMcpDeclarator(
      [](ai_vox::Engine& engine) { engine.AddMcpTool("user.ultrasonic_sensor.get_distance", "Get distance from US04 ultrasonic sensor", {}); });

  RegisterUserMcpHandler("user.ultrasonic_sensor.get_distance", [](const ai_vox::McpToolCallEvent& event) {
    const float distance = MeasureUs04UltrasonicDistance();

    if (distance < 0) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Failed to measure distance from US04 sensor");
    } else {
      printf("on mcp tool call: user.ultrasonic_sensor.get_distance, distance: %.1f cm\n", distance);
      ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, std::to_string(distance).c_str());
    }
  });
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(500);

  printf("\n========== US04 Initialization ==========\n");
  pinMode(kUs04PinTrig, OUTPUT);
  pinMode(kUs04PinEcho, INPUT);
  printf("========================================\n\n");

  McpToolUs04UltrasonicSensor();

  InitializeDevice();
}

void loop() {
  ProcessMainLoop();
}
