#include <Arduino.h>
#include <ArduinoJson.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include "servo.h"

namespace {

constexpr uint8_t kServoPin = 42;
constexpr uint8_t kFanPin = 32;
constexpr uint8_t kMotorInBPin = 1;
constexpr uint8_t kMotorInAPin = 2;
constexpr uint32_t kMinPulse = 500;
constexpr uint32_t kMaxPulse = 2500;
constexpr uint16_t kMaxServoAngle = 180;
constexpr uint16_t kHeadLeftAngle = 0;
constexpr uint16_t kHeadRightAngle = 180;
constexpr uint16_t kHeadCenterAngle = 90;

constexpr uint8_t kFanSpeedLevels[4] = {0, 120, 190, 255};

auto servo = em::Servo(kServoPin, 0, kMaxServoAngle, kMinPulse, kMaxPulse);

struct FanState {
  uint8_t headSwingLevel = 0;
  uint8_t fanSpeedLevel = 0;
  uint32_t lastUpdate = 0;
  bool isOscillating = false;
  uint16_t currentAngle = kHeadCenterAngle;
  bool directionRight = true;
};

FanState fanState;

void SetFanSpeed(uint8_t level) {
  if (level > 3) level = 3;

  const uint8_t speed = kFanSpeedLevels[level];

  digitalWrite(kMotorInBPin, LOW);
  analogWrite(kMotorInAPin, speed);
  printf("Motor running forward: speed=%d\n", speed);

  fanState.fanSpeedLevel = level;
  printf("Fan speed set to level: %d (PWM: %d)\n", level, speed);
}

void SetHeadSwingLevel(uint8_t level) {
  if (level > 3) level = 3;

  fanState.headSwingLevel = level;

  if (level == 0) {
    servo.Write(kHeadCenterAngle);
    fanState.currentAngle = kHeadCenterAngle;
    fanState.isOscillating = false;
    printf("Head swing stopped, returned to center\n");
  } else {
    fanState.isOscillating = true;
    printf("Head swing started at level: %d\n", level);
  }
}

void HandleHeadOscillation() {
  if (!fanState.isOscillating) return;

  uint32_t oscillationInterval;
  switch (fanState.headSwingLevel) {
    case 1:
      oscillationInterval = 1500;
      break;
    case 2:
      oscillationInterval = 1000;
      break;
    case 3:
      oscillationInterval = 500;
      break;
    default:
      oscillationInterval = 1500;
      break;
  }

  if (millis() - fanState.lastUpdate >= oscillationInterval) {
    if (fanState.directionRight) {
      fanState.currentAngle += 5;
      if (fanState.currentAngle >= kHeadRightAngle) {
        fanState.directionRight = false;
      }
    } else {
      fanState.currentAngle -= 5;
      if (fanState.currentAngle <= kHeadLeftAngle) {
        fanState.directionRight = true;
      }
    }
    printf("Servo angle updated: %d\n", fanState.currentAngle);
    servo.Write(fanState.currentAngle);
    fanState.lastUpdate = millis();
  }
}

/**
 * @brief MCP工具 - 控制摇头挡位
 *
 * 该函数注册一个名为 "user.control_head_swing" 的MCP工具，
 * 用于控制风扇摇头挡位。
 *
 * 工具名称: user.control_head_swing
 * 工具描述: Control head swing level 0-3
 *
 * 参数:
 *   - level (int64_t): 摇头挡位
 *     - required: 是
 *     - min: 0
 *     - max: 3
 *     - default_value: 无
 *     - 说明: 0表示停止摇头，1表示低速，2表示中速，3表示高速
 *
 * 返回值:
 *   - status: 操作状态 ("success")
 *   - level: 设置的挡位值
 *   - description: 挡位描述
 */
void McpToolControlHeadSwing() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.control_head_swing",
                      "Control head swing level 0-3",
                      {{"level",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = std::nullopt,
                            .min = 0,
                            .max = 3,
                        }}});
  });

  RegisterUserMcpHandler("user.control_head_swing", [](const ai_vox::McpToolCallEvent& event) {
    const auto level_ptr = event.param<int64_t>("level");

    if (level_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: level");
      return;
    }

    const int64_t level = *level_ptr;

    if (level < 0 || level > 3) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Level must be between 0 and 3");
      return;
    }

    SetHeadSwingLevel(static_cast<uint8_t>(level));
    printf("Head swing level set to: %d\n", static_cast<uint8_t>(level));

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["level"] = level;
    doc["description"] = level == 0 ? "Head swing OFF" : level == 1 ? "Head swing LOW" : level == 2 ? "Head swing MEDIUM" : "Head swing HIGH";

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

/**
 * @brief MCP工具 - 控制风扇挡位
 *
 * 该函数注册一个名为 "user.control_fan_speed" 的MCP工具，
 * 用于控制风扇风量挡位。
 *
 * 工具名称: user.control_fan_speed
 * 工具描述: Control fan speed level 0-3
 *
 * 参数:
 *   - level (int64_t): 风扇挡位
 *     - required: 是
 *     - min: 0
 *     - max: 3
 *     - default_value: 无
 *     - 说明: 0表示关闭风扇，1表示低速，2表示中速，3表示高速
 *
 * 返回值:
 *   - status: 操作状态 ("success")
 *   - level: 设置的挡位值
 *   - description: 挡位描述
 */
void McpToolControlFanSpeed() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.control_fan_speed",
                      "Control fan speed level 0-3",
                      {{"level",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = std::nullopt,
                            .min = 0,
                            .max = 3,
                        }}});
  });

  RegisterUserMcpHandler("user.control_fan_speed", [](const ai_vox::McpToolCallEvent& event) {
    const auto level_ptr = event.param<int64_t>("level");

    if (level_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: level");
      return;
    }

    const int64_t level = *level_ptr;

    if (level < 0 || level > 3) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Level must be between 0 and 3");
      return;
    }

    SetFanSpeed(static_cast<uint8_t>(level));
    printf("Fan speed level set to: %d\n", static_cast<uint8_t>(level));

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["level"] = level;
    doc["description"] = level == 0 ? "Fan OFF" : level == 1 ? "Fan LOW" : level == 2 ? "Fan MEDIUM" : "Fan HIGH";

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(500);

  if (!servo.Init()) {
    printf("Error: Failed to init servo on pin %d\n", kServoPin);
  }

  pinMode(kMotorInBPin, OUTPUT);
  pinMode(kMotorInAPin, OUTPUT);

  servo.Write(kHeadCenterAngle);
  fanState.currentAngle = kHeadCenterAngle;

  McpToolControlHeadSwing();
  McpToolControlFanSpeed();

  InitializeDevice();

  printf("Smart Oscillating Fan initialized\n");
}

void loop() {
  HandleHeadOscillation();

  ProcessMainLoop();
}
