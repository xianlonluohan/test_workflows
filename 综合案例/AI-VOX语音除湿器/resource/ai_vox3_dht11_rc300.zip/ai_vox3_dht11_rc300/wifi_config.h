// WiFi配置 - 请修改下面的WIFI_SSID和WIFI_PASSWORD
// #define WIFI_SSID "wifi_ssid_here"
// #define WIFI_PASSWORD "wifi_password_here"

#define WIFI_SSID "Alltman"
#define WIFI_PASSWORD "AlltmanSuccess"