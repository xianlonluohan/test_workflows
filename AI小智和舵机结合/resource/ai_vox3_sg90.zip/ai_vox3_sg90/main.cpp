#include <Arduino.h>
#include <ArduinoJson.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include "servo.h"

namespace {

constexpr uint8_t kServoPin = 42;
constexpr uint32_t kMinPulse = 500;
constexpr uint32_t kMaxPulse = 2500;
constexpr uint16_t kMaxServoAngle = 180;

auto servo = em::Servo(kServoPin, 0, kMaxServoAngle, kMinPulse, kMaxPulse);

/**
 * @brief MCP工具 - 控制9G舵机
 *
 * 该函数注册一个名为 "user.control_servo" 的MCP工具，用于控制舵机的角度。
 *
 * 工具名称: user.control_servo
 * 工具描述: Control servo angle
 *
 * 参数:
 *   - angle (int64_t): 舵机角度，范围0-180度
 *     - required: 是
 *     - min: 0
 *     - max: 180
 *     - default_value: 无
 *
 * 返回值:
 *   - status: 操作状态 ("success")
 *   - angle: 设置的角度值
 *   - gpio: 使用的GPIO引脚编号
 */
void McpToolControlServo() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.control_servo",
                      "Control servo angle",
                      {{"angle",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = std::nullopt,
                            .min = 0,
                            .max = kMaxServoAngle,
                        }}});
  });

  RegisterUserMcpHandler("user.control_servo", [](const ai_vox::McpToolCallEvent& event) {
    const auto angle_ptr = event.param<int64_t>("angle");

    if (angle_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: angle");
      return;
    }

    const int64_t angle = *angle_ptr;

    if (angle < 0 || angle > 180) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Angle must be between 0 and 180");
      return;
    }

    servo.Write(static_cast<uint16_t>(angle));
    printf("Servo moved to angle: %d (GPIO %d)\n", static_cast<uint16_t>(angle), static_cast<int>(kServoPin));

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["angle"] = angle;
    doc["gpio"] = static_cast<int>(kServoPin);

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(500);

  printf("\n========== Servo Initialization ==========\n");

  if (!servo.Init()) {
    printf("Error: Failed to init servo on pin %d\n", kServoPin);
  }

  servo.Write(90);

  printf("========================================\n\n");

  McpToolControlServo();

  InitializeDevice();
}

void loop() {
  ProcessMainLoop();
}
