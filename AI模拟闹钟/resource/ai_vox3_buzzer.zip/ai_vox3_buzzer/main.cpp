#include <Arduino.h>
#include <ArduinoJson.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

constexpr uint8_t kBuzzerPin = 3;

struct AlarmTimer {
  bool active = false;
  uint32_t start_time = 0;
  uint32_t duration_ms = 0;
  int8_t buzzer_state = 1;
  int64_t event_id = 0;
};

AlarmTimer current_alarm;

/**
 * @brief MCP工具 - 控制有源蜂鸣器报警
 *
 * 该函数注册一个名为 "user.buzzer.control" 的MCP工具，
 * 用于控制有源蜂鸣器的开关状态。
 *
 * 工具名称: user.buzzer.control
 * 工具描述: Control buzzer on/off
 *
 * 参数:
 *   - state (int64_t): 蜂鸣器状态
 *     - required: 是
 *     - min: 0
 *     - max: 1
 *     - default_value: 无
 *     - 说明: 0表示关闭蜂鸣器，1表示开启蜂鸣器
 *
 * 返回值:
 *   - status: 操作状态 ("success")
 *   - state: 设置的状态值
 *   - gpio: 使用的GPIO引脚编号
 */
void McpToolBuzzerControl() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.buzzer.control",
                      "Control buzzer on/off",
                      {{"state",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = std::nullopt,
                            .min = 0,
                            .max = 1,
                        }}});
  });

  RegisterUserMcpHandler("user.buzzer.control", [](const ai_vox::McpToolCallEvent& event) {
    const auto state_ptr = event.param<int64_t>("state");

    if (state_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: state (0=off, 1=on)");
      return;
    }

    const int64_t state = *state_ptr;

    if (state != 0 && state != 1) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "State must be 0 (off) or 1 (on)");
      return;
    }

    digitalWrite(kBuzzerPin, static_cast<uint8_t>(state));

    const char* state_str = (state == 1) ? "ON" : "OFF";
    printf("Buzzer turned %s (GPIO %d)\n", state_str, kBuzzerPin);

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["state"] = state;
    doc["gpio"] = kBuzzerPin;

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

/**
 * @brief MCP工具 - 设置定时闹钟
 *
 * 该函数注册一个名为 "user.alarm.timer" 的MCP工具，
 * 用于设置倒计时，在指定时间后激活蜂鸣器报警。
 *
 * 工具名称: user.alarm.timer
 * 工具描述: Set a countdown timer that triggers buzzer when time is up
 *
 * 参数:
 *   - seconds (int64_t): 倒计时秒数
 *     - required: 是
 *     - min: 1
 *     - max: 3600
 *     - default_value: 无
 *     - 说明: 最少1秒，最多1小时
 *
 *   - buzzer_state (int64_t): 倒计时结束后的蜂鸣器状态
 *     - required: 否
 *     - min: 0
 *     - max: 1
 *     - default_value: 1
 *     - 说明: 0表示关闭蜂鸣器，1表示开启蜂鸣器
 *
 * 返回值:
 *   - status: 操作状态 ("timer_started")
 *   - seconds: 设置的倒计时秒数
 *   - buzzer_state: 设置的蜂鸣器状态
 */
void McpToolAlarmTimer() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.alarm.timer",
                      "Set a countdown timer that triggers buzzer when time is up",
                      {{"seconds",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = std::nullopt,
                            .min = 1,
                            .max = 3600,
                        }},
                       {"buzzer_state",
                        ai_vox::ParamSchema<int64_t>{
                            .default_value = 1,
                            .min = 0,
                            .max = 1,
                        }}});
  });

  RegisterUserMcpHandler("user.alarm.timer", [](const ai_vox::McpToolCallEvent& event) {
    const auto seconds_ptr = event.param<int64_t>("seconds");
    const auto buzzer_state_ptr = event.param<int64_t>("buzzer_state");

    if (seconds_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: seconds (countdown duration in seconds)");
      return;
    }

    const int64_t seconds = *seconds_ptr;
    const int64_t buzzer_state = buzzer_state_ptr ? *buzzer_state_ptr : 1;

    if (seconds < 1 || seconds > 3600) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Seconds must be between 1 and 3600");
      return;
    }

    if (buzzer_state != 0 && buzzer_state != 1) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Buzzer state must be 0 (off) or 1 (on)");
      return;
    }

    current_alarm.active = true;
    current_alarm.start_time = millis();
    current_alarm.duration_ms = static_cast<uint32_t>(seconds * 1000);
    current_alarm.buzzer_state = static_cast<int8_t>(buzzer_state);
    current_alarm.event_id = event.id;

    printf("Starting alarm timer for %lld seconds\n", static_cast<long long>(seconds));

    DynamicJsonDocument doc(256);
    doc["status"] = "timer_started";
    doc["seconds"] = seconds;
    doc["buzzer_state"] = buzzer_state;

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

/**
 * @brief 检查并处理定时器到期事件
 *
 * 该函数在loop中定期调用，用于检查定时器是否到期，
 * 如果到期则触发蜂鸣器并发送响应。
 */
void CheckAndProcessAlarm() {
  if (current_alarm.active) {
    const uint32_t elapsed_time = millis() - current_alarm.start_time;

    if (elapsed_time >= current_alarm.duration_ms) {
      digitalWrite(kBuzzerPin, static_cast<uint8_t>(current_alarm.buzzer_state));

      const char* state_str = (current_alarm.buzzer_state == 1) ? "ON" : "OFF";
      printf("Alarm triggered! Buzzer turned %s (GPIO %d)\n", state_str, kBuzzerPin);

      DynamicJsonDocument response_doc(256);
      response_doc["status"] = "alarm_triggered";
      response_doc["buzzer_state"] = current_alarm.buzzer_state;
      response_doc["duration_seconds"] = current_alarm.duration_ms / 1000;

      String response_json;
      serializeJson(response_doc, response_json);

      ai_vox::Engine::GetInstance().SendMcpCallResponse(current_alarm.event_id, response_json.c_str());

      current_alarm.active = false;
    }
  }
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(kBuzzerPin, OUTPUT);
  digitalWrite(kBuzzerPin, LOW);

  McpToolBuzzerControl();
  McpToolAlarmTimer();

  InitializeDevice();
}

void loop() {
  CheckAndProcessAlarm();

  ProcessMainLoop();
}
