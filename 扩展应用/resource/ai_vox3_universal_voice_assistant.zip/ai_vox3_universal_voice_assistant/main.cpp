#include <Arduino.h>
#include <ArduinoJson.h>
#include <HardwareSerial.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

HardwareSerial UserSerial(2);

constexpr uint8_t kCustomTxPin = 6;
constexpr uint8_t kCustomRxPin = 5;

/**
 * @brief MCP工具 - 串口输出
 *
 * 该函数注册一个名为 "user.uart_output" 的MCP工具，
 * 用于通过串口发送数据到外部设备。
 *
 * 工具名称: user.uart_output
 * 工具描述: Send data through UART serial port. Use this to control external devices connected via serial port.
 *           Examples:
 *           - To turn on LED: 'turn on led'
 *
 * 参数:
 *   - data (std::string): 要发送的数据
 *     - required: 是
 *     - default_value: 无
 *     - 说明: 要通过串口发送的字符串数据
 *
 * 返回值:
 *   - status: 操作状态 ("success")
 *   - sent_data: 发送的数据内容
 *   - description: 操作描述 ("Data sent through UART serial port successfully")
 */
void McpToolUartOutput() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.uart_output",
                      "Send data through UART serial port. Use this to control external devices connected via serial port.\n"
                      "Examples:\n"
                      "- To turn on LED: 'turn on led'\n",
                      {{"data",
                        ai_vox::ParamSchema<std::string>{
                            .default_value = std::nullopt,
                        }}});
  });

  RegisterUserMcpHandler("user.uart_output", [](const ai_vox::McpToolCallEvent& event) {
    const auto data_ptr = event.param<std::string>("data");

    if (data_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: data");
      return;
    }

    const std::string data = *data_ptr;

    UserSerial.println(String(data.c_str()));
    printf("UART output: %s\n", data.c_str());

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["sent_data"] = data;
    doc["description"] = "Data sent through UART serial port successfully";

    String jsonString;
    serializeJson(doc, jsonString);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, jsonString.c_str());
  });
}

}  // namespace

void setup() {
  Serial.begin(115200);
  UserSerial.begin(115200, SERIAL_8N1, kCustomRxPin, kCustomTxPin);
  delay(500);

  McpToolUartOutput();

  InitializeDevice();
}

void loop() {
  ProcessMainLoop();
}
