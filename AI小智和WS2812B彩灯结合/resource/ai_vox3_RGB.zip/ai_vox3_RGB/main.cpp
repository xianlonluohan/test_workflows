/**
 * @file main.cpp
 * @brief AI VOX3 RGB彩灯控制示例
 *
 * 本示例展示如何使用AI VOX3框架控制WS2812B RGB彩灯
 * 支持设置全部灯珠颜色亮度和单独控制每个灯珠
 */

#include <Arduino.h>
#include <ArduinoJson.h>

#include "FastLED.h"
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

/**
 * @brief 硬件引脚配置
 * @note RGB灯带使用GPIO48，每个灯环包含12个灯珠
 */
constexpr uint8_t kRgbPin = 48;
constexpr uint8_t kRgbLedCount = 12;

/**
 * @brief RGB灯带全局缓冲区
 * @note 用于存储每个灯珠的颜色数据
 */
CRGB leds[kRgbLedCount];

/**
 * @brief MCP工具 - 设置全部RGB灯颜色和亮度
 *
 * 注册一个名为"user.set_all_rgb_light"的MCP工具
 * 用于同时控制所有RGB灯珠的状态、亮度和颜色
 *
 * 参数说明:
 *   - state: 灯状态，true为开，false为关（必填）
 *   - brightness: 亮度值，范围0-255（默认100）
 *   - r/g/b: RGB颜色分量，各0-255（默认0）
 */
void RegisterMcpToolSetAllRgbLight() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.set_all_rgb_light",
                      "Set all RGB light state, brightness and color",
                      {
                          {"state",
                           ai_vox::ParamSchema<bool>{
                               .default_value = std::nullopt,
                           }},
                          {"brightness",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 100,
                               .min = 0,
                               .max = 255,
                           }},
                          {"r",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                          {"g",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                          {"b",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                      });
  });

  RegisterUserMcpHandler("user.set_all_rgb_light", [](const ai_vox::McpToolCallEvent& event) {
    const auto state_ptr = event.param<bool>("state");
    const auto brightness_ptr = event.param<int64_t>("brightness");
    const auto red_ptr = event.param<int64_t>("r");
    const auto green_ptr = event.param<int64_t>("g");
    const auto blue_ptr = event.param<int64_t>("b");

    if (state_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: state");
      return;
    }

    const bool state = *state_ptr;
    const int64_t brightness = (brightness_ptr != nullptr) ? *brightness_ptr : 100;
    const int64_t red = (red_ptr != nullptr) ? *red_ptr : 0;
    const int64_t green = (green_ptr != nullptr) ? *green_ptr : 0;
    const int64_t blue = (blue_ptr != nullptr) ? *blue_ptr : 0;

    if (state) {
      FastLED.setBrightness(static_cast<uint8_t>(brightness));
      fill_solid(leds, kRgbLedCount, CRGB(static_cast<uint8_t>(red), static_cast<uint8_t>(green), static_cast<uint8_t>(blue)));
      FastLED.show();
    } else {
      fill_solid(leds, kRgbLedCount, CRGB::Black);
      FastLED.show();
    }

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, true);
  });
}

/**
 * @brief MCP工具 - 设置单个RGB灯珠
 *
 * 注册一个名为"user.set_single_rgb_light"的MCP工具
 * 用于控制指定编号灯珠的状态、亮度和颜色
 *
 * 参数说明:
 *   - index: 灯珠索引，0到kRgbLedCount-1（必填）
 *   - state: 灯状态，true为开，false为关（必填）
 *   - brightness: 亮度值，范围0-255（默认100）
 *   - r/g/b: RGB颜色分量，各0-255（默认0）
 */
void RegisterMcpToolSetSingleRgbLight() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.set_single_rgb_light",
                      "Set single RGB light state, brightness and color",
                      {
                          {"index",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = kRgbLedCount - 1,
                           }},
                          {"state",
                           ai_vox::ParamSchema<bool>{
                               .default_value = std::nullopt,
                           }},
                          {"brightness",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 100,
                               .min = 0,
                               .max = 255,
                           }},
                          {"r",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                          {"g",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                          {"b",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                      });
  });

  RegisterUserMcpHandler("user.set_single_rgb_light", [](const ai_vox::McpToolCallEvent& event) {
    const auto index_ptr = event.param<int64_t>("index");
    const auto state_ptr = event.param<bool>("state");
    const auto brightness_ptr = event.param<int64_t>("brightness");
    const auto red_ptr = event.param<int64_t>("r");
    const auto green_ptr = event.param<int64_t>("g");
    const auto blue_ptr = event.param<int64_t>("b");

    if (state_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: state");
      return;
    }

    if (index_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: index");
      return;
    }

    const int64_t index = *index_ptr;
    const bool state = *state_ptr;
    const int64_t brightness = (brightness_ptr != nullptr) ? *brightness_ptr : 100;
    const int64_t red = (red_ptr != nullptr) ? *red_ptr : 0;
    const int64_t green = (green_ptr != nullptr) ? *green_ptr : 0;
    const int64_t blue = (blue_ptr != nullptr) ? *blue_ptr : 0;

    if (index < 0 || index >= kRgbLedCount) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Index out of range. Valid range: 0-" + std::to_string(kRgbLedCount - 1));
      return;
    }

    if (state) {
      leds[index] = CRGB(static_cast<uint8_t>(red), static_cast<uint8_t>(green), static_cast<uint8_t>(blue));
    } else {
      leds[index] = CRGB::Black;
    }

    FastLED.setBrightness(static_cast<uint8_t>(brightness));
    FastLED.show();

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, true);
  });
}

/**
 * @brief MCP工具 - 获取单个RGB灯珠状态
 *
 * 注册一个名为"user.get_single_rgb_light"的MCP工具
 * 用于获取指定灯珠的当前状态、亮度和颜色
 *
 * 参数说明:
 *   - index: 灯珠索引，0到kRgbLedCount-1（必填）
 */
void RegisterMcpToolGetSingleRgbLight() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.get_single_rgb_light",
                      "Get single RGB light state, brightness and color",
                      {
                          {"index",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = kRgbLedCount - 1,
                           }},
                      });
  });

  RegisterUserMcpHandler("user.get_single_rgb_light", [](const ai_vox::McpToolCallEvent& event) {
    const auto index_ptr = event.param<int64_t>("index");

    if (index_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: index");
      return;
    }

    const int64_t index = *index_ptr;

    if (index < 0 || index >= kRgbLedCount) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Index out of range. Valid range: 0-" + std::to_string(kRgbLedCount - 1));
      return;
    }

    const CRGB current_color = leds[index];
    const uint8_t current_brightness = FastLED.getBrightness();
    const bool is_light_on = (current_color != CRGB::Black);

    DynamicJsonDocument doc(512);
    doc["index"] = index;
    doc["state"] = is_light_on;
    doc["brightness"] = static_cast<int64_t>(current_brightness);
    doc["r"] = static_cast<int64_t>(current_color.r);
    doc["g"] = static_cast<int64_t>(current_color.g);
    doc["b"] = static_cast<int64_t>(current_color.b);

    String json_string;
    serializeJson(doc, json_string);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, json_string.c_str());
  });
}

}  // namespace

/**
 * @brief Arduino setup函数
 *
 * 系统上电后执行一次的初始化代码
 *
 * 初始化流程:
 * 1. 启动串口通信 (115200波特率)
 * 2. 初始化RGB灯硬件 (FastLED)
 * 3. 注册MCP工具 (让AI能够控制RGB灯)
 * 4. 初始化AI VOX3设备 (屏幕、音频、WiFi等)
 */
void setup() {
  Serial.begin(115200);

  FastLED.addLeds<NEOPIXEL, kRgbPin>(leds, kRgbLedCount);
  FastLED.setBrightness(100);
  FastLED.clear();
  FastLED.show();

  RegisterMcpToolSetAllRgbLight();
  RegisterMcpToolSetSingleRgbLight();
  RegisterMcpToolGetSingleRgbLight();

  InitializeDevice();
}

/**
 * @brief Arduino主循环函数
 *
 * 系统主循环，持续重复执行
 * 负责处理AI引擎事件循环、MCP工具调用、UI更新等
 */
void loop() {
  ProcessMainLoop();
}
