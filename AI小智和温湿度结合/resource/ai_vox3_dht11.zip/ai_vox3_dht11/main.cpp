/**
 * @file main.cpp
 * @brief AI VOX3 DHT11温湿度传感器示例
 *
 * 本示例展示如何使用AI VOX3框架读取DHT11温湿度传感器的数据
 */

#include <Arduino.h>
#include <ArduinoJson.h>

#include "DHT.h"
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

/**
 * @brief 硬件配置
 * @note DHT11传感器连接GPIO4
 */
constexpr uint8_t kDhtPin = 4;
constexpr uint8_t kDhtType = DHT11;

DHT dht(kDhtPin, kDhtType);

/**
 * @brief MCP工具 - 读取温湿度数据
 *
 * 注册一个名为"user.read_temperature_humidity"的MCP工具
 * 用于获取DHT11传感器的温度和湿度数据
 *
 * 返回值说明:
 *   - temperature: 温度值（摄氏度）
 *   - humidity: 湿度值（百分比）
 *   - feels_like_temperature: 体感温度
 */
void RegisterMcpToolReadTemperatureHumidity() {
  RegisterUserMcpDeclarator(
      [](ai_vox::Engine& engine) { engine.AddMcpTool("user.read_temperature_humidity", "Read temperature and humidity from DHT11 sensor", {}); });

  RegisterUserMcpHandler("user.read_temperature_humidity", [](const ai_vox::McpToolCallEvent& event) {
    const float humidity = dht.readHumidity();
    const float temperature = dht.readTemperature();

    printf("====temp:%d hum:%d\n", static_cast<int32_t>(temperature), static_cast<int32_t>(humidity));

    if (isnan(humidity) || isnan(temperature)) {
      Serial.println(F("无法从 DHT 传感器读取数据，请检查接线!"));
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Failed to read from DHT sensor");
      return;
    }

    const float heat_index = dht.computeHeatIndex(temperature, humidity, false);

    DynamicJsonDocument doc(256);
    doc["temperature"] = temperature;
    doc["humidity"] = humidity;
    doc["feels_like_temperature"] = heat_index;

    String json_string;
    serializeJson(doc, json_string);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, json_string.c_str());
  });
}

}  // namespace

/**
 * @brief Arduino setup函数
 */
void setup() {
  Serial.begin(115200);
  dht.begin();

  RegisterMcpToolReadTemperatureHumidity();
  InitializeDevice();
}

/**
 * @brief Arduino主循环函数
 */
void loop() {
  ProcessMainLoop();
}
