/**
 * @file main.cpp
 * @brief AI VOX3 光敏传感器与LED控制示例
 *
 * 本示例展示如何使用AI VOX3框架读取光敏传感器数值
 * 并控制用户LED的开关状态
 */

#include <Arduino.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

/**
 * @brief 硬件引脚配置
 * @note 光敏传感器连接GPIO3，LED连接GPIO1
 */
constexpr uint8_t kPhotosensitivePin = 3;
constexpr uint8_t kLedPin = 1;

/**
 * @brief MCP工具 - 读取光敏传感器值
 *
 * 注册一个名为"user.read_light_sensor"的MCP工具
 * 用于读取光敏传感器的模拟值
 *
 * 返回值说明:
 *   - 返回0-4095的模拟值，数值越大表示光线越强
 */
void RegisterMcpToolReadLightSensor() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) { engine.AddMcpTool("user.read_light_sensor", "Read light sensor value", {}); });

  RegisterUserMcpHandler("user.read_light_sensor", [](const ai_vox::McpToolCallEvent& event) {
    const int32_t light_value = analogRead(kPhotosensitivePin);
    printf("Light sensor value: %d\n", light_value);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, light_value);
  });
}

/**
 * @brief MCP工具 - 开启LED
 *
 * 注册一个名为"user.led_on"的MCP工具
 * 用于将用户LED设置为高电平点亮
 */
void RegisterMcpToolLedOn() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) { engine.AddMcpTool("user.led_on", "Turn on user LED", {}); });

  RegisterUserMcpHandler("user.led_on", [](const ai_vox::McpToolCallEvent& event) {
    printf("LED on\n");
    digitalWrite(kLedPin, HIGH);
    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, true);
  });
}

/**
 * @brief MCP工具 - 关闭LED
 *
 * 注册一个名为"user.led_off"的MCP工具
 * 用于将用户LED设置为低电平熄灭
 */
void RegisterMcpToolLedOff() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) { engine.AddMcpTool("user.led_off", "Turn off user LED", {}); });

  RegisterUserMcpHandler("user.led_off", [](const ai_vox::McpToolCallEvent& event) {
    printf("LED off\n");
    digitalWrite(kLedPin, LOW);
    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, true);
  });
}

}  // namespace

/**
 * @brief Arduino setup函数
 *
 * 系统上电后执行一次的初始化代码
 *
 * 初始化流程:
 * 1. 配置GPIO引脚模式
 * 2. 注册MCP工具
 * 3. 初始化AI VOX3设备
 */
void setup() {
  pinMode(kPhotosensitivePin, INPUT);
  pinMode(kLedPin, OUTPUT);

  RegisterMcpToolReadLightSensor();
  RegisterMcpToolLedOn();
  RegisterMcpToolLedOff();

  InitializeDevice();
}

/**
 * @brief Arduino主循环函数
 */
void loop() {
  ProcessMainLoop();
}
