/**
 * @file main.cpp
 * @brief AI VOX3 RC300电机控制示例
 *
 * 本示例展示如何使用AI VOX3框架控制RC300电机的正反转和转速
 */

#include <Arduino.h>
#include <ArduinoJson.h>

#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

namespace {

/**
 * @brief 硬件引脚配置
 * @note RC300电机驱动模块的INB和INA控制引脚
 */
constexpr uint8_t kMotorInbPin = 1;
constexpr uint8_t kMotorInaPin = 2;

/**
 * @brief MCP工具 - 控制电机转动
 *
 * 注册一个名为"user.control_motor"的MCP工具
 * 用于控制电机的正反转和转速
 *
 * 参数说明:
 *   - direction: 转动方向，true为正向，false为反向（必填）
 *   - speed: 转速，范围0-255（默认0）
 */
void RegisterMcpToolControlMotor() {
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine) {
    engine.AddMcpTool("user.control_motor",
                      "Control motor direction and speed",
                      {
                          {"direction",
                           ai_vox::ParamSchema<bool>{
                               .default_value = std::nullopt,
                           }},
                          {"speed",
                           ai_vox::ParamSchema<int64_t>{
                               .default_value = 0,
                               .min = 0,
                               .max = 255,
                           }},
                      });
  });

  RegisterUserMcpHandler("user.control_motor", [](const ai_vox::McpToolCallEvent& event) {
    const auto direction_ptr = event.param<bool>("direction");
    const auto speed_ptr = event.param<int64_t>("speed");

    if (direction_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: direction");
      return;
    }

    if (speed_ptr == nullptr) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Missing required argument: speed");
      return;
    }

    const bool direction_value = *direction_ptr;
    const int64_t speed = *speed_ptr;

    if (speed < 0 || speed > 255) {
      ai_vox::Engine::GetInstance().SendMcpCallError(event.id, "Speed must be between 0 and 255");
      return;
    }

    if (speed == 0) {
      analogWrite(kMotorInaPin, 0);
      analogWrite(kMotorInbPin, 0);
      digitalWrite(kMotorInaPin, LOW);
      digitalWrite(kMotorInbPin, LOW);
      printf("Motor stopped\n");
    } else if (direction_value) {
      digitalWrite(kMotorInaPin, LOW);
      digitalWrite(kMotorInbPin, LOW);
      delay(50);
      digitalWrite(kMotorInbPin, LOW);
      analogWrite(kMotorInaPin, static_cast<uint8_t>(speed));
      printf("Motor running forward: speed=%d\n", static_cast<uint8_t>(speed));
    } else {
      digitalWrite(kMotorInaPin, LOW);
      digitalWrite(kMotorInbPin, LOW);
      delay(50);
      digitalWrite(kMotorInaPin, LOW);
      analogWrite(kMotorInbPin, static_cast<uint8_t>(speed));
      printf("Motor running backward: speed=%d\n", static_cast<uint8_t>(speed));
    }

    printf("Motor running: direction=%s, speed=%d\n", direction_value ? "true" : "false", static_cast<uint8_t>(speed));

    DynamicJsonDocument doc(256);
    doc["status"] = "success";
    doc["direction"] = direction_value;
    doc["speed"] = speed;

    String json_string;
    serializeJson(doc, json_string);

    ai_vox::Engine::GetInstance().SendMcpCallResponse(event.id, json_string.c_str());
  });
}

}  // namespace

/**
 * @brief Arduino setup函数
 */
void setup() {
  Serial.begin(115200);

  pinMode(kMotorInbPin, OUTPUT);
  pinMode(kMotorInaPin, OUTPUT);

  RegisterMcpToolControlMotor();
  InitializeDevice();
}

/**
 * @brief Arduino主循环函数
 */
void loop() {
  ProcessMainLoop();
}
